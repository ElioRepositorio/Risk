/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Juego_2Proceso;

/**
 *
 * @author ManTequila
 */
public class Reforzarse {
    
    
    
}


/*
metodo
4 ejércitos a cambio de tres tarjetas de Infantería.
6 ejércitos a cambio de tres tarjetas de Caballería.
8 ejércitos a cambio de tres tarjetas de Artillería.
10 ejércitos a cambio de tres tarjetas con la combinación Infantería-Caballería-Artillería.
Los comodines sirven, por supuesto, en el objetivo de ayudar a formar alguna de esas tríadas.
SubMetodo o comprobacion si se tiene 5 o 6 cartas al principio del turno, se debe cambiar al menos un conjunto y se tiene la opción de cambiar el segundo





metodo
Continente	n.º de tropas extra
África	
3
Oceanía	
2
Asia	
7
Europa	
5
América del Norte	
5
América del Sur	
2





metodo
Territorios ocupados	Número de ejércitos
< 12	3
12-14	4
15-17	5
18-20	6
21-23	7
24-26	8
27-29	9
30-32	10
33-35	11
36-38	12
39-41	13




El territorio específico mostrado en una carta canjeada: si una de las tres tarjetas Risk que se cambia muestra la imagen de un territorio que ocupas, se recibirá el valor del dibujo de ejércitos extras que deberán ser ubicadas en dicho territorio. De suceder eso con dos o con las tres cartas, el jugador igualmente recibirá sólo dos unidades, aunque tendrá la opción de ubicar ambos ejércitos en el territorio de su preferencia, siempre que sea uno de los ilustrados en las tarjetas canjeadas.
Ataque a los enemigos

*/
