/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Juego_2Proceso;

import Servidor.Jugador;
import Juego_1Inicio.Pais;
import java.util.ArrayList;

/**
 *
 * @author ManTequila
 */
public class MoverTropas {
   
    /* metodos de jugador (herencia)
    
         public void colocarTropas(int tropasAColocar) {
        // Colocar automáticamente 1 tropa en cada territorio
        for (Pais pais : paises) {
            pais.tropas += 1;
        }

        // Permitir al jugador seleccionar la ubicación de las tropas restantes
        for (Pais pais : paises) {
            int tropasRestantes = tropasAColocar - 1; // Restar la tropa automática ya colocada

            while (tropasRestantes > 0) {
                // Lógica para manejar la interfaz gráfica y decrementar tropasRestantes
                // según las elecciones del jugador
                // ...

                // Actualizar la interfaz gráfica mostrando las tropas restantes y
                // permitir que el jugador continúe seleccionando territorios
                // ...
            }
        }*/
    }
